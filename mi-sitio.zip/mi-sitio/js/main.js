/* =========================================================
   PERSONALIZA AQUÍ: las frases que se escriben en la portada
   ========================================================= */
const ROLES = ['diseñador/a', 'creativo/a', 'desarrollador/a web', 'apasionado/a por aprender'];

/* ---------- Texto que se escribe solo ---------- */
(function typing() {
    const el = document.getElementById('typed');
    let i = 0, j = 0, borrando = false;

    function tick() {
        const palabra = ROLES[i];
        el.textContent = palabra.slice(0, borrando ? --j : ++j);
        let espera = borrando ? 40 : 90;

        if (!borrando && j === palabra.length) { borrando = true; espera = 1400; }
        else if (borrando && j === 0) { borrando = false; i = (i + 1) % ROLES.length; espera = 400; }

        setTimeout(tick, espera);
    }
    tick();
})();

/* ---------- Luz que sigue al mouse en la portada ---------- */
const hero = document.getElementById('hero');
hero.addEventListener('pointermove', (e) => {
    const r = hero.getBoundingClientRect();
    hero.style.setProperty('--mx', (e.clientX - r.left) + 'px');
    hero.style.setProperty('--my', (e.clientY - r.top) + 'px');
});

/* ---------- Menú en celular ---------- */
const menuBtn = document.querySelector('.menu-btn');
const menu = document.querySelector('.nav-link');
menuBtn.addEventListener('click', () => {
    const abierto = menu.classList.toggle('open');
    menuBtn.setAttribute('aria-expanded', abierto);
});
menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => menu.classList.remove('open')));

/* ---------- Modo claro / oscuro (se recuerda) ---------- */
const root = document.documentElement;
try {
    const guardado = localStorage.getItem('tema');
    if (guardado) root.dataset.theme = guardado;
} catch (e) {}

document.querySelector('.theme-btn').addEventListener('click', () => {
    const nuevo = root.dataset.theme === 'dark' ? 'light' : 'dark';
    root.dataset.theme = nuevo;
    try { localStorage.setItem('tema', nuevo); } catch (e) {}
});

/* ---------- Animaciones al hacer scroll ---------- */
const observer = new IntersectionObserver((entradas) => {
    entradas.forEach((entrada) => {
        if (!entrada.isIntersecting) return;
        const el = entrada.target;
        el.classList.add('visible');

        // Barras de habilidades
        el.querySelectorAll('.bar i').forEach(b => b.style.width = b.dataset.level + '%');

        // Contadores
        el.querySelectorAll('[data-count]').forEach(contar);

        observer.unobserve(el);
    });
}, { threshold: 0.25 });

document.querySelectorAll('.reveal, .skills').forEach(el => observer.observe(el));

function contar(el) {
    const meta = +el.dataset.count;
    let n = 0;
    const paso = setInterval(() => {
        el.textContent = ++n;
        if (n >= meta) clearInterval(paso);
    }, 1400 / meta);
}

/* ---------- Visor de fotos ---------- */
const lightbox = document.getElementById('lightbox');
const lbImg = lightbox.querySelector('.lb-img');

document.querySelectorAll('.foto').forEach((foto) => {
    foto.addEventListener('click', () => {
        lbImg.style.backgroundImage = getComputedStyle(foto).backgroundImage;
        lightbox.hidden = false;
    });
});
lightbox.addEventListener('click', (e) => { if (e.target !== lbImg) lightbox.hidden = true; });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') lightbox.hidden = true; });

/* ---------- Formulario: abre tu correo con el mensaje ---------- */
const CORREO = 'tucorreo@ejemplo.com'; // <-- cambia por tu correo real

document.getElementById('contact-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    const asunto = encodeURIComponent('Mensaje de ' + f.get('nombre'));
    const cuerpo = encodeURIComponent(f.get('mensaje') + '\n\n' + f.get('email'));
    window.location.href = `mailto:${CORREO}?subject=${asunto}&body=${cuerpo}`;
});

/* ---------- Año del pie de página ---------- */
document.getElementById('year').textContent = new Date().getFullYear();
